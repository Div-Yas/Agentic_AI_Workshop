import streamlit as st
import requests
import pandas as pd
import json
from io import StringIO
import os
import re

st.set_page_config(page_title="Bank Reconciliation System", layout="wide")

st.markdown("""
    <style>
    /* Make file upload button blue */
    .stFileUploader > label div[data-testid="stFileUploaderDropzone"] {
        background-color: #1976d2 !important;
        color: white !important;
        border-radius: 8px;
        border: 2px solid #1976d2 !important;
    }
    .stFileUploader > label div[data-testid="stFileUploaderDropzone"]:hover {
        background-color: #1565c0 !important;
        color: white !important;
    }
    /* Make action buttons green */
    button[kind="primary"], .stButton > button {
        background-color: #43a047 !important;
        color: white !important;
        border-radius: 8px;
        border: 2px solid #43a047 !important;
    }
    button[kind="primary"]:hover, .stButton > button:hover {
        background-color: #388e3c !important;
        color: white !important;
    }
    </style>
""", unsafe_allow_html=True)

st.title("Bank Reconciliation System")
st.write("Upload your bank statement and books records for automatic reconciliation")

# Sample files section
st.subheader("Sample Files")
col1, col2 = st.columns(2)

with col1:
    if st.button("Download Sample Bank Statement"):
        with open("../data/sample_bank_statement.csv", "r") as f:
            st.download_button(
                label="Click to Download Sample Bank Statement",
                data=f,
                file_name="sample_bank_statement.csv",
                mime="text/csv"
            )

with col2:
    if st.button("Download Sample Books Records"):
        with open("../data/sample_books.csv", "r") as f:
            st.download_button(
                label="Click to Download Sample Books Records",
                data=f,
                file_name="sample_books.csv",
                mime="text/csv"
            )

# File upload section
st.subheader("Upload Your Files")
col1, col2 = st.columns(2)

with col1:
    bank_statement = st.file_uploader("Upload Bank Statement (CSV)", type=['csv'])
    if bank_statement:
        try:
            df_bank = pd.read_csv(bank_statement)
            st.write("Bank Statement Preview:")
            st.dataframe(df_bank, use_container_width=True, height=400)
            bank_statement.seek(0)
        except Exception as e:
            st.error(f"Error reading bank statement: {str(e)}")

with col2:
    books = st.file_uploader("Upload Books Records (CSV)", type=['csv'])
    if books:
        try:
            df_books = pd.read_csv(books)
            st.write("Books Records Preview:")
            st.dataframe(df_books, use_container_width=True, height=400)
            books.seek(0)
        except Exception as e:
            st.error(f"Error reading books records: {str(e)}")

# Process button
if st.button("Process Reconciliation") and bank_statement and books:
    try:
        files = {
            'bank_statement': ('bank_statement.csv', bank_statement),
            'books': ('books.csv', books)
        }
        with st.spinner('Processing reconciliation...'):
            response = requests.post("http://localhost:8000/upload", files=files)
        if response.status_code == 200:
            result = response.json()

            # Debug: Show raw API response
            with st.expander("Debug - Raw API Response"):
                st.json(result)

            # Matched Transactions
            st.subheader("Matched Transactions")
            matches_content = result.get('matches', {}).get('content', '')
            
            if matches_content:
                matches_content = matches_content.replace('```json', '').replace('```', '').strip()
                
                # Debug: Show raw content
                with st.expander("Debug - Raw Matches Content"):
                    st.text(matches_content)
                
                matches_json = None
                
                # Robust JSON parsing with iterative trimming
                for i in range(5): # Try up to 5 times to trim and parse
                    try:
                        matches_json = json.loads(matches_content)
                        break
                    except json.JSONDecodeError as e:
                        if "Extra data" in str(e):
                            st.warning(f"JSONDecodeError: {e}. Attempting to trim and re-parse matched content.")
                            # Attempt to find the end of a valid JSON and trim
                            # This regex matches a valid JSON object or array at the beginning of the string
                            json_match = re.match(r'(\{.*?\}|\[.*?\])', matches_content, re.DOTALL)
                            if json_match:
                                matches_content = json_match.group(0)
                            else:
                                # Fallback: trim one character at a time
                                matches_content = matches_content[:-1]
                        else:
                            st.error(f"Could not parse JSON for Matched Transactions (attempt {i+1}): {e}")
                            st.text("Raw content that failed to parse:")
                            st.text(matches_content)
                            matches_json = None
                            break
                
                if matches_json is None:
                    # If direct parsing fails, try to extract JSON using regex patterns
                    json_patterns = [
                        r'\\{[\\s\\S]*\\}',  # Object pattern
                        r'\\[[\\s\\S]*\\]',  # Array pattern
                        r'(\\{(?:[^{}]|{[^{}]*})*\\})',  # Nested object pattern
                    ]
                    
                    for pattern in json_patterns:
                        json_match = re.search(pattern, matches_content)
                        if json_match:
                            try:
                                matches_json = json.loads(json_match.group(0))
                                break
                            except json.JSONDecodeError:
                                continue
                
                # If still no valid JSON found after all attempts
                if matches_json is None:
                    st.error("No valid JSON could be extracted or parsed for Matched Transactions.")
                    st.text("Final content attempted to parse:")
                    st.text(matches_content)

                # Process the parsed JSON
                if matches_json:
                    try:
                        matches_list = []
                        
                        if isinstance(matches_json, dict):
                            possible_keys = ['matches', 'matched_transactions', 'items', 'data']
                            for key in possible_keys:
                                if key in matches_json:
                                    matches_list = matches_json[key]
                                    break
                            if not matches_list and any(k in matches_json for k in ['bank_index', 'book_index']):
                                matches_list = [matches_json]
                                
                        elif isinstance(matches_json, list):
                            matches_list = matches_json
                        
                        if matches_list:
                            for i, item in enumerate(matches_list):
                                st.markdown(f"### Matched Transaction {i+1}")
                                if isinstance(item, dict):
                                    st.markdown(f"""
                                    **Bank Index:** {item.get('bank_index', 'N/A')}  
                                    **Book Index:** {item.get('book_index', 'N/A')}  
                                    **Bank Description:** {item.get('bank_description', 'N/A')}  
                                    **Book Description:** {item.get('book_description', 'N/A')}  
                                    **Amount:** {item.get('amount', 'N/A')}  
                                    **Score:** {item.get('score', 'N/A')}
                                    """)
                                else:
                                    st.write(f"Item: {item}")
                                st.markdown("---")
                        else:
                            st.write("No matched transactions found in the parsed data")
                            
                    except Exception as e:
                        st.error(f"Error processing matched transactions: {e}")
                        st.json(matches_json)
                else:
                    st.write("No matched transactions found")

            # Unreconciled Items - Improved parsing
            unreconciled_content = result.get('unreconciled', {}).get('content', '')

            if unreconciled_content:
                # Clean the content
                unreconciled_content = unreconciled_content.replace('```json', '').replace('```', '').strip()
                
                unreconciled_json = None

                # Robust JSON parsing with iterative trimming for unreconciled items
                for i in range(5):  # Try up to 5 times to trim and parse
                    try:
                        unreconciled_json = json.loads(unreconciled_content)
                        break
                    except json.JSONDecodeError as e:
                        if "Extra data" in str(e):
                            st.warning(f"JSONDecodeError: {e}. Attempting to trim and re-parse unreconciled content.")
                            json_match = re.match(r'(\{.*?\}|\[.*?\])', unreconciled_content, re.DOTALL)
                            if json_match:
                                unreconciled_content = json_match.group(0)
                            else:
                                unreconciled_content = unreconciled_content[:-1]
                        else:
                            st.error(f"Could not parse JSON for Unreconciled Items (attempt {i+1}): {e}")
                            st.text("Raw content that failed to parse:")
                            st.text(unreconciled_content)
                            unreconciled_json = None
                            break
                
                if unreconciled_json is None:
                    # If direct parsing fails, try to extract JSON using regex patterns
                    json_patterns = [
                        r'\\{[\\s\\S]*\\}',
                        r'\\[[\\s\\S]*\\]',
                        r'(\\{(?:[^{}]|{[^{}]*})*\\})',
                    ]
                    
                    for pattern in json_patterns:
                        json_match = re.search(pattern, unreconciled_content)
                        if json_match:
                            try:
                                unreconciled_json = json.loads(json_match.group(0))
                                break
                            except json.JSONDecodeError:
                                continue
                
                # If still no valid JSON found after all attempts
                if unreconciled_json is None:
                    st.error("No valid JSON could be extracted or parsed for Unreconciled Items.")
                    st.text("Final content attempted to parse:")
                    st.text(unreconciled_content)

                # Process the parsed JSON
                if unreconciled_json:
                    try:
                        unreconciled_items = []
                        
                        if isinstance(unreconciled_json, dict):
                            possible_keys = ['unreconciled_items', 'unreconciled', 'items', 'data']
                            for key in possible_keys:
                                if key in unreconciled_json:
                                    unreconciled_items = unreconciled_json[key]
                                    break
                            
                            if not unreconciled_items and any(k in unreconciled_json for k in ['bank_transaction_id', 'book_transaction_id']):
                                unreconciled_items = [unreconciled_json]
                                
                        elif isinstance(unreconciled_json, list):
                            unreconciled_items = unreconciled_json
                        
                        if unreconciled_items:
                            for i, item in enumerate(unreconciled_items):
                                st.markdown(f"### Unreconciled Item {i+1}")
                                if isinstance(item, dict):
                                    st.markdown(f"""
                                    **Bank Transaction ID:** {item.get('bank_transaction_id', 'N/A')}  
                                    **Book Transaction ID:** {item.get('book_transaction_id', 'N/A')}  
                                    **Bank Description:** {item.get('bank_description', 'N/A')}  
                                    **Book Description:** {item.get('book_description', 'N/A')}  
                                    **Bank Amount:** {item.get('bank_amount', 'N/A')}  
                                    **Book Amount:** {item.get('book_amount', 'N/A')}  
                                    **Discrepancy:** {item.get('discrepancy', 'N/A')}  
                                    **Suggested Fix:** {item.get('suggested_fix', 'N/A')}
                                    """)
                                else:
                                    st.write(f"Item: {item}")
                                st.markdown("---")
                        else:
                            st.write("No unreconciled items found in the parsed data")
                            
                    except Exception as e:
                        st.error(f"Error processing unreconciled items: {e}")
                        st.json(unreconciled_json)
            else:
                st.write("No unreconciled items found")
        else:
            st.error(f"Error processing files: {response.text}")
    except Exception as e:
        st.error(f"An error occurred: {str(e)}")

# Instructions
with st.expander("How to use"):
    st.write("""
    1. Download the sample files to understand the required format
    2. Prepare your bank statement and books records in CSV format
    3. Upload both files using the file uploaders above
    4. Click 'Process Reconciliation' to start the matching process
    5. Review the matched and unreconciled items
    6. Take action on any suggested fixes
    """) 