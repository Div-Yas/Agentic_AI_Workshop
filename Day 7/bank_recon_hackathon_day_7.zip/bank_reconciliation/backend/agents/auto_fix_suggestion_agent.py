class AutoFixSuggestionAgent:
    def __init__(self, llm, knowledge_agent):
        self.llm = llm
        self.knowledge_agent = knowledge_agent

    def suggest(self, discrepancy):
        context = self.knowledge_agent.get_context("bank reconciliation best practices")
        prompt = f"""
        Context: {context}
        Discrepancy: {discrepancy}
        Suggest a fix or next action for this discrepancy.
        """
        return self.llm.invoke(prompt) 