class DiscrepancyDetectorAgent:
    def detect(self, bank_df, books_df, matches, unmatched_bank, unmatched_books):
        discrepancies = []
        # Unmatched bank entries
        for idx in unmatched_bank:
            discrepancies.append({
                "type": "missing_in_books",
                "bank_row": bank_df.loc[idx].to_dict(),
                "reason": "No matching entry in books"
            })
        # Unmatched book entries
        for idx in unmatched_books:
            discrepancies.append({
                "type": "missing_in_bank",
                "book_row": books_df.loc[idx].to_dict(),
                "reason": "No matching entry in bank"
            })
        # Mismatches in matches
        for match in matches:
            if match['score'] < 100:
                discrepancies.append({
                    "type": "fuzzy_match",
                    "bank_row": bank_df.loc[match['bank_index']].to_dict(),
                    "book_row": books_df.loc[match['book_index']].to_dict(),
                    "reason": f"Fuzzy match with score {match['score']}"
                })
        return discrepancies 