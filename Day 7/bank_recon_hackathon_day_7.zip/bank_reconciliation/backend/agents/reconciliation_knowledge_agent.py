class ReconciliationKnowledgeAgent:
    def __init__(self, retriever, llm):
        self.retriever = retriever
        self.llm = llm

    def get_context(self, query):
        docs = self.retriever.get_relevant_documents(query)
        return "\n".join([doc.page_content for doc in docs]) 