import pandas as pd
from rapidfuzz import fuzz

class TransactionMatchingAgent:
    def __init__(self, threshold=80):
        self.threshold = threshold  # Fuzzy match threshold

    def match(self, bank_df: pd.DataFrame, books_df: pd.DataFrame):
        matches = []
        unmatched_bank = []
        unmatched_books = set(books_df.index)

        for idx, bank_row in bank_df.iterrows():
            best_score = 0
            best_match = None
            for jdx, book_row in books_df.iterrows():
                score = fuzz.token_sort_ratio(str(bank_row['description']), str(book_row['description']))
                amount_match = abs(float(bank_row['amount']) - float(book_row['amount'])) < 0.01
                if score > best_score and amount_match:
                    best_score = score
                    best_match = jdx
            if best_score >= self.threshold and best_match is not None:
                matches.append({
                    "bank_index": idx,
                    "book_index": best_match,
                    "bank_description": bank_row['description'],
                    "book_description": books_df.loc[best_match, 'description'],
                    "amount": bank_row['amount'],
                    "score": best_score
                })
                unmatched_books.discard(best_match)
            else:
                unmatched_bank.append(idx)
        return matches, unmatched_bank, list(unmatched_books) 