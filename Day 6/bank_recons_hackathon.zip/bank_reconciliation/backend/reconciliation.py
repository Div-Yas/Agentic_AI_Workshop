from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
import pandas as pd
from typing import List, Dict
import config

class BankReconciliation:
    def __init__(self):
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=config.GOOGLE_API_KEY,
            temperature=0.7
        )
        
    def load_data(self, bank_statement_path: str, books_path: str) -> tuple:
        """Load bank statement and books data"""
        bank_df = pd.read_csv(bank_statement_path)
        books_df = pd.read_csv(books_path)
        return bank_df, books_df
    
    def fuzzy_match_transactions(self, bank_df: pd.DataFrame, books_df: pd.DataFrame) -> List[Dict]:
        """Match transactions using fuzzy matching"""
        prompt = PromptTemplate(
            input_variables=["bank_transactions", "book_transactions"],
            template="""
            Compare these transactions and find matches:
            Bank Transactions:
            {bank_transactions}
            
            Book Transactions:
            {book_transactions}
            
            Return matches in JSON format with confidence scores.
            """
        )
        
        # Convert DataFrames to string format
        bank_str = bank_df.to_string()
        books_str = books_df.to_string()
        
        # Get matches from LLM
        response = self.llm.invoke(
            prompt.format(
                bank_transactions=bank_str,
                book_transactions=books_str
            )
        )
        
        return response
    
    def find_unreconciled_items(self, bank_df: pd.DataFrame, books_df: pd.DataFrame, matches: List[Dict]) -> Dict:
        """Find unreconciled items and suggest fixes"""
        prompt = PromptTemplate(
            input_variables=["bank_df", "books_df", "matches"],
            template="""
            Analyze these unreconciled transactions and suggest fixes:
            Bank Transactions:
            {bank_df}
            
            Book Transactions:
            {books_df}
            
            Current Matches:
            {matches}
            
            Return unreconciled items and suggested fixes in JSON format.
            """
        )
        
        response = self.llm.invoke(
            prompt.format(
                bank_df=bank_df.to_string(),
                books_df=books_df.to_string(),
                matches=str(matches)
            )
        )
        
        return response
    
    def process_reconciliation(self, bank_statement_path: str, books_path: str) -> Dict:
        """Main reconciliation process"""
        # Load data
        bank_df, books_df = self.load_data(bank_statement_path, books_path)
        
        # Find matches
        matches = self.fuzzy_match_transactions(bank_df, books_df)
        
        # Find unreconciled items
        unreconciled = self.find_unreconciled_items(bank_df, books_df, matches)
        
        return {
            "matches": matches,
            "unreconciled": unreconciled
        } 