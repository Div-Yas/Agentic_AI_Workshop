from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
from reconciliation import BankReconciliation
import os
from typing import Dict
import tempfile

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize reconciliation engine
reconciliation_engine = BankReconciliation()

@app.post("/upload")
async def upload_files(
    bank_statement: UploadFile = File(...),
    books: UploadFile = File(...)
) -> Dict:
    """Upload bank statement and books files"""
    try:
        # Create a temporary directory
        with tempfile.TemporaryDirectory() as temp_dir:
            # Save uploaded files
            bank_path = os.path.join(temp_dir, "bank_statement.csv")
            books_path = os.path.join(temp_dir, "books.csv")
            
            # Read and save bank statement
            bank_content = await bank_statement.read()
            with open(bank_path, "wb") as f:
                f.write(bank_content)
            
            # Read and save books
            books_content = await books.read()
            with open(books_path, "wb") as f:
                f.write(books_content)
            
            # Verify files are not empty
            if os.path.getsize(bank_path) == 0 or os.path.getsize(books_path) == 0:
                return {"error": "One or both files are empty"}
            
            # Process reconciliation
            result = reconciliation_engine.process_reconciliation(bank_path, books_path)
            return result
            
    except Exception as e:
        return {"error": str(e)}

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy"} 